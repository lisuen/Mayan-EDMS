default_app_config = 'mayan.apps.authentication.apps.AuthenticationApp'
