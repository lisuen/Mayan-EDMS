default_app_config = 'mayan.apps.acls.apps.ACLsApp'
