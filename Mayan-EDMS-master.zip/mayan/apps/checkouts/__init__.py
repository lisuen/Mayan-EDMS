default_app_config = 'mayan.apps.checkouts.apps.CheckoutsApp'
