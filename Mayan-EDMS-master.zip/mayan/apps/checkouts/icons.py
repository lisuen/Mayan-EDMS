from mayan.apps.appearance.classes import Icon

icon_check_in_document = Icon(
    driver_name='fontawesome-dual', primary_symbol='shopping-cart',
    secondary_symbol='minus'
)
icon_check_out_document = Icon(
    driver_name='fontawesome-dual', primary_symbol='shopping-cart',
    secondary_symbol='plus'
)
icon_check_out_info = Icon(driver_name='fontawesome', symbol='shopping-cart')
icon_dashboard_check_outs = Icon(
    driver_name='fontawesome', symbol='shopping-cart'
)
