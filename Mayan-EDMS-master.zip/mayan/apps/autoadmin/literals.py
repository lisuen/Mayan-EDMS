DEFAULT_EMAIL = 'autoadmin@example.com'
DEFAULT_PASSWORD = None
DEFAULT_USERNAME = 'admin'
