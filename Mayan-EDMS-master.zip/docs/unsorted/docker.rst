######
Docker
######

Docker is a container technology. Containers are a standard unit of software
that packages up code and all its dependencies.

.. include:: ../chapters/docker.rst
